import time

from PyQt6.QtWidgets import QMainWindow, QMessageBox
from app.design.main_window import Ui_MainWindow


class App(QMainWindow, Ui_MainWindow):

    def __init__(self):
        super(App, self).__init__()
        self.setupUi(self)

        self.setWindowTitle("ВЫСТАВКА СОБАК")

        self.inform_app()

    def inform_app(self):
        QMessageBox.information(self, "ИНФОРМАЦИЯ", "Функционал не реализован")
