from sqlalchemy import Column, ForeignKey, Integer, String

from db.conn import Base


class Dog(Base):
    __tablename__ = 'dog'

    dog_id = Column(Integer, primary_key=True, autoincrement=True)
    club_id = Column(Integer, ForeignKey("dog_club.club_id"))
    nickname = Column(String, nullable=False)
    class_ = Column(String, nullable=False, name="class")
    age = Column(String, nullable=False)
    injection_date = Column(String, nullable=False)
    boss_id = Column(Integer, ForeignKey("dog_boss.boss_id"))
    medal = Column(String)


class DogBoss(Base):
    __tablename__ = 'dog_boss'

    boss_id = Column(Integer, primary_key=True, autoincrement=True)
    f_name = Column(String, nullable=False)
    s_name = Column(String, nullable=False)
    t_name = Column(String, nullable=False)
    off_doc = Column(String, nullable=False)


class Expert(Base):
    __tablename__ = 'expert'

    expert_id = Column(Integer, primary_key=True, autoincrement=True)
    f_name = Column(String, nullable=False)
    s_name = Column(String, nullable=False)
    exp_club = Column(String, nullable=False)
    dog_club_id = Column(Integer, ForeignKey("dog_club.club_id"))


class DogClub(Base):
    __tablename__ = 'dog_club'

    club_id = Column(Integer, primary_key=True, autoincrement=True)
    personal_ring = Column(String, nullable=False)
