from pydantic import BaseModel, Field


class SDog(BaseModel):
    dog_id: int = Field(...)
    club_id: int = Field(...)
    nickname: str = Field(...)
    class_ = Field(..., alias="class")
    age: str = Field(...)
    injection_date: str = Field(...)
    boss_id: int = Field(...)
    medal: str = Field(None)

    class Config:
        orm_mode = True


class SDogBoss(BaseModel):
    boss_id: int = Field(...)
    f_name: str = Field(...)
    s_name: str = Field(...)
    t_name: str = Field(...)
    off_doc: str = Field(...)

    class Config:
        orm_mode = True


class SExpert(BaseModel):
    expert_id: int = Field(...)
    f_name: str = Field(...)
    s_name: str = Field(...)
    exp_club: str = Field(...)
    dog_club_id: int = Field(...)

    class Config:
        orm_mode = True


class SDogClub(BaseModel):
    club_id: int = Field(...)
    personal_ring: str = Field(...)

    class Config:
        orm_mode = True
