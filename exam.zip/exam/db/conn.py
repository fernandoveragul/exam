from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker, Session

DB_URL = "mssql+pymssql://0_311_2:p@ssword@localhost:1433"

Base = declarative_base()

engine = create_engine(DB_URL)
session = sessionmaker(engine, autoflush=False, expire_on_commit=False)


def get_session() -> Session:
    with session() as ses:
        return ses
